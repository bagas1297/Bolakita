
import 'package:flutter/material.dart';

class MatchScreen extends StatelessWidget {
  const MatchScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Match screen Page', style: TextStyle(fontSize: 24)));
  }
}
