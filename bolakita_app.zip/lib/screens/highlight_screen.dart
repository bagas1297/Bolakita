
import 'package:flutter/material.dart';

class HighlightScreen extends StatelessWidget {
  const HighlightScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Highlight screen Page', style: TextStyle(fontSize: 24)));
  }
}
