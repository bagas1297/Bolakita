
import 'package:flutter/material.dart';

class ForumScreen extends StatelessWidget {
  const ForumScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Forum screen Page', style: TextStyle(fontSize: 24)));
  }
}
