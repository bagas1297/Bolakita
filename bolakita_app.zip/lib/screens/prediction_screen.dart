
import 'package:flutter/material.dart';

class PredictionScreen extends StatelessWidget {
  const PredictionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Prediction screen Page', style: TextStyle(fontSize: 24)));
  }
}
