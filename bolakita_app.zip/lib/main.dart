// Flutter Main Entry
import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/news_screen.dart';
import 'screens/match_screen.dart';
import 'screens/standings_screen.dart';
import 'screens/highlight_screen.dart';
import 'screens/prediction_screen.dart';
import 'screens/favorite_screen.dart';
import 'screens/forum_screen.dart';

void main() => runApp(const BolaKitaApp());

class BolaKitaApp extends StatefulWidget {
  const BolaKitaApp({super.key});

  @override
  State<BolaKitaApp> createState() => _BolaKitaAppState();
}

class _BolaKitaAppState extends State<BolaKitaApp> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    HomeScreen(),
    MatchScreen(),
    StandingsScreen(),
    NewsScreen(),
    HighlightScreen(),
    PredictionScreen(),
    FavoriteScreen(),
    ForumScreen(),
  ];

  final List<BottomNavigationBarItem> _navItems = const [
    BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
    BottomNavigationBarItem(icon: Icon(Icons.sports_soccer), label: 'Live'),
    BottomNavigationBarItem(icon: Icon(Icons.table_chart), label: 'Klasemen'),
    BottomNavigationBarItem(icon: Icon(Icons.article), label: 'Berita'),
    BottomNavigationBarItem(icon: Icon(Icons.play_circle_fill), label: 'Highlight'),
    BottomNavigationBarItem(icon: Icon(Icons.analytics), label: 'Prediksi'),
    BottomNavigationBarItem(icon: Icon(Icons.favorite), label: 'Favorit'),
    BottomNavigationBarItem(icon: Icon(Icons.forum), label: 'Forum'),
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BolaKita',
      theme: ThemeData(
        brightness: Brightness.dark,
        primarySwatch: Colors.green,
        scaffoldBackgroundColor: const Color(0xFF121212),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1F1F1F),
        ),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: Color(0xFF1F1F1F),
          selectedItemColor: Colors.greenAccent,
          unselectedItemColor: Colors.grey,
        ),
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text('BolaKita'),
          centerTitle: true,
        ),
        body: AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          child: _screens[_currentIndex],
        ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _currentIndex,
          type: BottomNavigationBarType.fixed,
          items: _navItems,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
        ),
      ),
    );
  }
}
